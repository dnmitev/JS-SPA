you can view drivers info like writing its id directly in order: ......./drivers/:id
I didn't managae well my time and I had no time to do this smart. Thank you for being kind.
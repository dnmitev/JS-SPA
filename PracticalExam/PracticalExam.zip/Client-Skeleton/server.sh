cd app
node ../scripts/web-server.js
